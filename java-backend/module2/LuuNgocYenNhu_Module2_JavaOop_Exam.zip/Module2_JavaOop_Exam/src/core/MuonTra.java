package core;

import exception.NgoaiLeHetSach;

public interface MuonTra {
    void muon() throws NgoaiLeHetSach;
    void tra();
}
