package exception;

public class NgoaiLeHetSach extends Exception {
    public NgoaiLeHetSach(String message) {
        super(message);
    }
}
