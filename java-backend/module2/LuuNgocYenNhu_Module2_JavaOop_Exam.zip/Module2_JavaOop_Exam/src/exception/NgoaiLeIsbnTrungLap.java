package exception;

public class NgoaiLeIsbnTrungLap extends Exception {
    public NgoaiLeIsbnTrungLap(String message) {
        super(message);
    }
}
