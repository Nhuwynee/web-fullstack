package model;

public enum LoaiYeuCau { MUON, TRA }
